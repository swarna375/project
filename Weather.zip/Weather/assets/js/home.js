//api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}


const weatherApi = {
  key: "e159c8f05d2b3f6ad18cfff98adff708",
  baseUrl: "https://api.openweathermap.org/data/2.5/weather?"
}

const searchinputbox = document.getElementById('input-box');

searchinputbox.addEventListener('keypress', (event) => {
  if(event.keyCode == 13) {
    console.log(searchinputbox.value);
    getWeatherReport(searchinputbox.value);
  }
});

function getWeatherReport(city) {
  fetch('${weatherApi.baseUrl}?q=${city}&appid=${weatherApi.key}&units=metric')
  .then(weather => {
    return weather.json();
  }).then(showWeatherReport);
}

function showWeatherReport(weather){
  console.log(weather);

  let city = document.getElementById('city');
  city.innerText = '$(weather.name), $(weather.sys.country)';

}

//api.openweathermap.org/data/2.5/forecast?q={city name}&appid={API key}

//https://api.openweathermap.org/data/2.5/onecall?lat={lat}&lon={lon}&exclude={part}&appid={API key}

//https://tile.openweathermap.org/map/{layer}/{z}/{x}/{y}.png?appid={API key}
